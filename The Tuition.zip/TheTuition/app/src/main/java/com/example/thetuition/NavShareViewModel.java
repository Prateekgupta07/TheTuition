package com.example.thetuition;

import androidx.lifecycle.ViewModel;

public class NavShareViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}