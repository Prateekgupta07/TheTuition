package com.example.thetuition;

import androidx.lifecycle.ViewModel;

public class NavContactViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}