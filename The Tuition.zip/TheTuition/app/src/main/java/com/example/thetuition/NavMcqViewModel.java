package com.example.thetuition;

import androidx.lifecycle.ViewModel;

public class NavMcqViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}